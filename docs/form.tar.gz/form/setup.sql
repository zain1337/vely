create table if not exists names (firstName varchar(30), lastName varchar(40));
