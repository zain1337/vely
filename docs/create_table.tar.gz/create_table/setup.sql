create table if not exists my_table (col1 bigint);
