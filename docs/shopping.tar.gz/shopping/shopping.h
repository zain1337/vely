#include "vely.h"

void _json_from_order (const char *order_id, num curr_order, num order_count, 
    const char *customer_id, const char *first_name, const char *last_name);
