#include "vely.h"

void _json_from_order (char *order_id, num curr_order, num order_count, 
    char *customer_id, char *first_name, char *last_name);
