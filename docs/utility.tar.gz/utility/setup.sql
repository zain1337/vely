create table temps (temp integer, timest text primary key);
