create table if not exists stock (stock_name varchar(100) primary key, stock_price bigint);
